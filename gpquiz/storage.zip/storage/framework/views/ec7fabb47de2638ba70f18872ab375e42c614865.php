<?php $__env->startSection('content'); ?>
<div class="col-md-12 corpo carro">
    <div class="container">
        <div class="col-md-8 col-md-offset-2 logo logo-perguntas text-left">

            <div class="col-md-6 no-padding">
                <img src="/assets/logo.png" class="img-responsive">

                <div class="tempo">
                    <span>Fique de olho no seu tempo!</span>
                    <div>00:<i>00</i></div>
                </div>
            </div>



            <div class="col-md-6 no-padding">
                
            </div>

            <div class="col-md-12 no-padding text-left opcoes">
                <span class="questao"><?php echo e($question->question); ?></span>

                <?php if($question->image): ?>
                    <img src="<?php echo e(url("question/{$question->image}")); ?>" class="img-responsive" alt="">
                <?php endif; ?>

                <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button class="button resposta" id="q<?php echo e($answer->order); ?>" data-resposta="<?php echo e($answer->order); ?>"><?php echo e($answer->answer); ?></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <form id="enviar-questao" method="POST" action="/perguntas/<?php echo e($question->id); ?>/salvar">

                <?php echo e(csrf_field()); ?>


                <input type="hidden" name="answer" id="answer" value="0"/>
            </form>

            <div class="col-md-12 text-center">
                <button type="button" class="button" id="proxima">CONFIRMAR</button>
            </div>

            <br><br><br>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/countdown/2.6.0/countdown.js"></script>

    <script>

    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    $(function(){
        $('#proxima').click(function(e){
            var resposta = $(".opcoes .button.active").data('resposta');
            $("#answer").val(resposta);

            $("#enviar-questao").submit();
        });

        $(".resposta").click(function() {
            $("#proxima").show();
            $(".resposta").removeClass("active");
            $(this).addClass("active");
        });



        var seconds = 30;
        var el = $('.tempo i');

        function incrementSeconds() {

            seconds -= 1;
            if(seconds < 10){
                el.text("0" + seconds.toString());
            } else {
                el.text(seconds.toString());
            }


            if(seconds <= 0){
                $('#enviar-questao').submit();
                clearInterval(cancel);

            }

        }

        var cancel = setInterval(incrementSeconds, 1000);


    });



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
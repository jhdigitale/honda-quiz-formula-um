<table width="100%" text-align="center">
    <tr width="100%" text-align="center">
        <td text-align="center"><img src="assets/logo.png"></td>
    </tr>
    <tr>
        <td><br><br><b>Nome</b>: <?php echo e($data['user']->nome); ?></td>
    </tr>
    <tr>
        <td><b>Email</b>: <?php echo e($data['user']->email); ?></td>
    </tr>
    <tr>
        <td><b>Matrícula</b>:<?php echo e($data['user']->register); ?></td>
    </tr>
    <tr>
        <td><b>CPF</b>: <?php echo e($data['user']->cpf); ?></td>
    </tr>
    <tr>
        <td><b>Planta</b>: <?php echo e($data['user']->local); ?></td>
    </tr>
</table>

<?php $__currentLoopData = $data['questions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <table>
        <tr>
            <td><h4>
                    <?php echo e($question->order); ?>.<?php echo e($question->question); ?>

                </h4>
            </td>
        </tr>

        <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td>
                    <?php if($answer->order == $question->reposta): ?>
                        <b><?php echo e($answer->answer); ?></b>
                    <?php else: ?>
                        <?php echo e($answer->answer); ?>

                    <?php endif; ?>

                </td>
            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
